---
layout: page
title: Contact
permalink: /about/
---

Instructor: Hao-Chuan Wang 
- Email: hciwang at ucdavis.edu
- Course website: http://hciwang.github.io 
- Office hour: By Appointment
- Location: 3025 Kemper Hall

TA: Shilpika
- Email: fshilpika at ucdavis.edu
- Office hour: Wednesday, 5:00PM - 7:00PM
- Location: 55 Kemper Hall 

